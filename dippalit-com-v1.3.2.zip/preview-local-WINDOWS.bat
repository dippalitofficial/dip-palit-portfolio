@echo off
REM ============================================================
REM  Local preview for dippalit.com
REM
REM  Double-clicking index.html does NOT work properly, because
REM  a file:// URL cannot serve index.html for a folder — your
REM  browser shows a directory listing instead of the page.
REM
REM  This starts a tiny local web server so the site behaves
REM  exactly like it will on your real host.
REM
REM  Double-click this file, then leave the black window open
REM  while you browse. Close it when you're done.
REM
REM  This file does nothing on a live server. You can upload it
REM  or delete it, either is fine.
REM ============================================================

cd /d "%~dp0"
echo.
echo   Starting local preview of dippalit.com
echo   Open this address in your browser:
echo.
echo       http://localhost:8080/
echo.
echo   Leave this window open while browsing.
echo   Press Ctrl+C or close the window to stop.
echo.

start "" http://localhost:8080/

python -m http.server 8080 2>nul
if errorlevel 1 (
  py -3 -m http.server 8080 2>nul
)
if errorlevel 1 (
  echo.
  echo   Python is not installed.
  echo   Install it from https://python.org ^(tick "Add to PATH"^),
  echo   or just upload the site to your host and preview it there.
  echo.
  pause
)
