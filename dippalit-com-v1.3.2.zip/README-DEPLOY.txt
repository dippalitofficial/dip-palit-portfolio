═══════════════════════════════════════════════════════════════════════════
  DIPPALIT.COM — COMPLETE STATIC WEBSITE
  v1.3.1 · 28 pages + 404 · no build step, no dependencies
═══════════════════════════════════════════════════════════════════════════

Everything in this folder is finished and ready to upload. There is nothing
to compile, install or configure. Upload the contents and the site works.


───────────────────────────────────────────────────────────────────────────
1. WHAT'S IN HERE
───────────────────────────────────────────────────────────────────────────

  index.html                    Homepage
  404.html                      Error page
  about/  services/  tools/     One folder per page, each with index.html
  pricing/  contact/  faq/
  case-studies/  resources/
  blog/                         Hub + 8 article folders
  assets/css/style.css          All styling (one file, 37 KB)
  assets/js/main.js             Nav, FAQ accordions, contact form
  sitemap.xml                   All 28 URLs, ready for Search Console
  robots.txt                    Allows Google + AI crawlers explicitly
  llms.txt                      Structured summary for AI search engines
  _headers  _redirects          Netlify / Cloudflare Pages config
  .htaccess                     Apache / cPanel config
  preview-local-WINDOWS.bat     Local preview launcher (see below)
  preview-local-MAC.command     Local preview launcher (see below)
  README-DEPLOY.txt             This file

Total: 34 files. No images to upload — your photo loads from Imgur and all
icons are Font Awesome from CDN.


───────────────────────────────────────────────────────────────────────────
2. UPLOAD IT
───────────────────────────────────────────────────────────────────────────

Pick whichever matches your host. All three work identically.

  ── NETLIFY (easiest, free) ──
  1. Go to app.netlify.com  ->  "Add new site"  ->  "Deploy manually"
  2. Drag this entire folder onto the drop zone
  3. Done. Netlify reads _headers and _redirects automatically.

  ── CPANEL / SHARED HOSTING (Hostinger, Namecheap, GoDaddy, etc.) ──
  1. Open File Manager  ->  public_html
  2. Delete anything already in there
  3. Upload the CONTENTS of this folder (not the folder itself)
     -- index.html must sit directly in public_html, not in a subfolder
  4. Make sure .htaccess uploaded. It starts with a dot, so file managers
     often hide it: enable "show hidden files" and confirm it's there.

  ── VERCEL / CLOUDFLARE PAGES ──
  Drag-and-drop deploy, or push to a GitHub repo and connect it.
  No build command. No output directory. It's already built.


───────────────────────────────────────────────────────────────────────────
3. CONNECT DIPPALIT.COM
───────────────────────────────────────────────────────────────────────────

  ── If you used Netlify ──
  Site settings -> Domain management -> Add custom domain -> dippalit.com
  Netlify shows you the exact DNS records. At your domain registrar, either:
    - point the nameservers to Netlify's (simplest), or
    - add an A record for @ and a CNAME for www, as Netlify specifies
  Then: Domain management -> HTTPS -> Verify DNS -> Provision certificate.
  DNS takes 15 minutes to 48 hours to propagate. Usually well under an hour.

  ── If you used cPanel hosting ──
  Add dippalit.com as the primary domain in cPanel, then at your registrar
  point the nameservers to the ones your host gave you.
  Then in cPanel: SSL/TLS Status -> Run AutoSSL. Free certificate, ~10 mins.

  ── Either way, before you go further ──
  Visit https://dippalit.com and confirm:
    [ ] The padlock shows (HTTPS working)
    [ ] http:// redirects to https://
    [ ] www.dippalit.com redirects to dippalit.com (or vice versa —
        just pick one and be consistent; the .htaccess defaults to non-www)
    [ ] A made-up URL like /nothing-here/ shows your 404 page


───────────────────────────────────────────────────────────────────────────
4. GET IT INDEXED  (do this the same day)
───────────────────────────────────────────────────────────────────────────

  GOOGLE SEARCH CONSOLE  — search.google.com/search-console
  1. Add property -> Domain -> dippalit.com
  2. Verify with the TXT record it gives you (add at your registrar)
  3. Sitemaps -> enter: sitemap.xml -> Submit
  4. URL Inspection -> paste https://dippalit.com/ -> Request Indexing
  5. Repeat step 4 for these five. They're your money pages:
       /services/mca-specialist/
       /services/dot-compliance-specialist/
       /resources/dot-compliance-checklist/
       /blog/fmcsa-new-entrant-safety-audit-guide/
       /pricing/

  BING WEBMASTER TOOLS — bing.com/webmasters
  You can import directly from Search Console in two clicks. Do it — Bing
  feeds ChatGPT search, so this matters more than it used to.

  Then update your links: Upwork profile, LinkedIn, any directory listings.
  Point them at dippalit.com. External links are the single biggest factor
  in how fast Google trusts a new domain.

  Realistic timeline: indexed in 3–14 days. Ranking movement on the niche
  MCA and DOT terms in 6–12 weeks. Do not panic in week two.


───────────────────────────────────────────────────────────────────────────
5. THREE THINGS I NEED YOU TO CHECK
───────────────────────────────────────────────────────────────────────────

  (a) THE $60K FIGURE — please verify this
      Your old site said "$41K+" in the page title but "$60K+" in the body
      and the schema markup. I standardised everything on $60K+.
      If $41K is the correct number, tell me and I'll change it everywhere.
      Do not leave two different numbers live — a prospect who notices will
      not ask you about it, they'll just leave.

  (b) TESTIMONIALS — the one real gap
      I did not invent client quotes. Fake testimonials are worse than none.
      Instead, open index.html and search for:  TESTIMONIAL TEMPLATE
      There's a commented-out block with instructions. Paste in real quotes
      as you collect them and delete the <!-- --> comment markers.
      Ask your three best Upwork clients this week. One sentence each is
      enough, with a first name, a role and a company type. This is the
      highest-value hour of work available to you right now.

  (c) BOOKING LINK — currently missing
      You didn't give me a Calendly or similar, so every call-to-action
      points at the contact form, Upwork, WhatsApp or email. That works,
      but a direct booking link converts noticeably better for an
      appointment-setting service. If you set one up, send it to me and
      I'll wire it into every CTA.


───────────────────────────────────────────────────────────────────────────
6. HOW TO EDIT THINGS YOURSELF
───────────────────────────────────────────────────────────────────────────

  CHANGE A COLOUR OR FONT
  assets/css/style.css, lines 1–40. Everything is a CSS variable:
      --navy, --blue, --ink, --muted, --line, --bg, --radius
  Change it once at the top and every page updates.

  CHANGE YOUR EMAIL / UPWORK / WHATSAPP LINK
  Find-and-replace across all files. Your current values:
      dippalitofficial@gmail.com
      https://www.upwork.com/freelancers/~017494125bf2bd8aa8
      https://wa.link/pbduj5
      https://www.linkedin.com/in/dippalit01

  CHANGE YOUR PHOTO
  Currently https://i.imgur.com/zqJgmgn.png, referenced in every page's
  schema and OG tags. If you swap it, find-and-replace the URL.
  Better: upload it to assets/img/ and use a local path — faster, and it
  won't break if Imgur goes down.

  THE CONTACT FORM
  Posts to your existing Formspree endpoint (formspree.io/f/meedlzvg) over
  AJAX, with a graceful fallback if JavaScript fails. Already working —
  send yourself a test message after launch to confirm.

  ADD A BLOG POST
  Copy any folder from blog/, rename it to your new slug, edit the content,
  then add the URL to sitemap.xml and a card to blog/index.html.


───────────────────────────────────────────────────────────────────────────
7. WHAT I BUILT INTO THIS THAT YOU CAN'T SEE
───────────────────────────────────────────────────────────────────────────

  73 blocks of structured data across 28 pages:
    Person, WebSite, ProfessionalService, Service (x7), FAQPage (x19),
    BreadcrumbList (x27), BlogPosting (x8), Article (x2), HowTo (x2),
    Blog, ItemList, AboutPage, ContactPage

  Why it matters: FAQPage and HowTo markup are what get you pulled into
  AI answers and featured snippets. 19 FAQ blocks across the site is the
  main reason this should perform in ChatGPT and Perplexity results, not
  just Google.

  llms.txt — an emerging standard that gives AI crawlers a clean summary
  of who you are and what each page covers. Costs nothing, might help.

  robots.txt explicitly allows GPTBot, ClaudeBot, PerplexityBot and
  Google-Extended. Most sites accidentally block these.

  Accessibility: skip links, keyboard-operable FAQ accordions, ARIA labels,
  reduced-motion support, every image has alt text. Google measures this.

  Performance: one 37 KB stylesheet instead of 650 lines of CSS repeated
  inline on every page — which is what your old site did. Cache headers
  set to one year on assets. Print styles so the two checklists print
  cleanly on one page, which is how people will actually use them.

  Redirects: your old URLs (services.html, tools.html, mca-cold-caller.html,
  the /solutions/ paths, and the old hash anchors) all 301 to the new clean
  URLs. Any existing links or rankings carry over instead of 404ing.


───────────────────────────────────────────────────────────────────────────
8. FIRST 30 DAYS — WHAT ACTUALLY MOVES THE NEEDLE
───────────────────────────────────────────────────────────────────────────

  Week 1   Deploy. Submit sitemap. Request indexing on the six pages above.
           Update the link on your Upwork and LinkedIn profiles.
  Week 1   Collect three real testimonials and add them.
  Week 2   Confirm indexing in Search Console. Fix anything flagged.
  Week 3   Post one of the blog articles as a LinkedIn post in your own
           words, linking back. The DOT audit guide is the strongest one.
  Week 4   Check Search Console -> Performance for which queries you're
           appearing on. Those queries tell you what to write next.

  The two DOT compliance pages are your genuine competitive advantage.
  Almost nobody in cold calling holds an FMCSA compliance certification,
  and almost nobody writing about FMCSA compliance sells outbound. You sit
  in the overlap, and the site is built to make that overlap obvious.

───────────────────────────────────────────────────────────────────────────
9. WHAT CHANGED IN v1.2  (styling only — no content, no URLs, no schema)
───────────────────────────────────────────────────────────────────────────

  Only two files differ from v1.0: assets/css/style.css and
  assets/js/main.js. Every page, URL, word and schema block is identical,
  so nothing about your SEO setup changes.

  KEPT ON PURPOSE
  Navy #0F172A and blue #2563EB, Raleway headings, Nunito body, the card
  layout, and all 196 class names. It should still look like your site.

  THE MAIN IDEA
  Your whole pitch rests on verifiable numbers, so the numbers are now the
  most deliberate thing on the page: tabular figures (digits line up in
  columns), tighter letter-spacing, and a rule connecting each number to
  its label. Everything around them got quieter to let them carry weight.

  WHAT GOT MODERNISED
  - Fluid type. Text scales smoothly with screen width via clamp() instead
    of jumping at breakpoints, so there are no awkward in-between sizes.
  - Intrinsic grids. Cards now reflow based on available space rather than
    fixed column counts, which removed most of the media queries.
  - A token system. Colours, spacing, radii and shadows are defined once at
    the top of the file. Change --blue in one place and the whole site
    follows, including every tint, which is now derived with color-mix().
  - Layered shadows and a radius hierarchy (8 / 14 / 22px by role) instead
    of one shadow and one radius on everything.
  - Dark mode, for visitors whose device is set to dark. Section 21 of the
    stylesheet — delete that block if you'd rather ship light-only.

  THREE THINGS DELIBERATELY REMOVED
  - ALL-CAPS tracked-out labels above every heading. They're the single
    commonest tell of a templated site and they read poorly at small sizes.
    Same words, now sentence case with a short rule.
  - The identical hover-lift on every card. It now only happens on cards
    that are genuinely clickable, so hover means something.
  - Scattered scroll animations. The fade-in is now 6px and fast — present
    but never delaying your reader.

  FIXES CARRIED IN
  - The mobile menu no longer injects hardcoded white styling from
    JavaScript, so it works in dark mode and closes on Escape, on outside
    click, and after you tap a link.
  - Four classes that were never styled in v1.0 now are (hero-content,
    hero-stat, about-sidebar, contact-form-side).
  - Better print output: FAQ answers expand when printed, and pages break
    sensibly between sections.

  HOW TO CHECK IT QUICKLY
  Open index.html, a blog post, /pricing/ and /contact/. Resize the window
  narrow and wide. Tap the mobile menu. Open a FAQ. Print the DOT checklist
  to PDF. That covers every component on the site.

  ── FIXED IN v1.2.1 (styling bugs found by rendering every page) ──
  Nine real bugs, caught by opening the pages in a browser rather than
  reading the CSS:

  1. Hero was broken. The photo is a sibling of the text block, not a
     child, so the two-column rule was on the wrong element and the
     headline, stats and buttons got spread across two columns.
  2. Card headings rendered as blue underlined hyperlinks. Service and
     niche card titles wrap a link and had lost their colour reset.
  3. Breadcrumbs overlapped the navbar on all 28 interior pages. The
     breadcrumb is a <nav> element and a bare `nav { position: fixed }`
     rule was pinning it to the top of the viewport.
  4. The contact form showed "Message sent" permanently — the success
     message had lost its hidden-by-default rule.
  5. Duplicate tick marks on 81 checklist items and 21 pricing rows,
     where the markup already supplies an icon.
  6. A large empty gap in every pricing card, from pinning an element
     to the card foot that isn't actually last in the markup.
  7. The Upwork band had turned grey; it is a blue gradient again.
  8. The process section on 8 pages had turned white; it is navy again.
  9. The print button was invisible against the light header.

  Also fixed in v1.2.2: the portrait is a circle again, cropped to fill
  the blue disc behind it (top-centre, so the face stays in frame); the
  three cards around the photo drift again on a 4s loop; the footer's
  bottom line is centred prose again rather than being flung to both
  edges; and the footer link columns no longer show bullets.

  Also: the hamburger now has a guaranteed 44px tap target even if the
  icon font fails to load. Verified at 360, 390, 768 and 1280px, plus
  dark mode and print.

  v1.0 is preserved — if you prefer the old look, tell me and I'll restore
  it. Nothing else would need to change.

───────────────────────────────────────────────────────────────────────────
10. PREVIEWING THE SITE ON YOUR OWN COMPUTER
───────────────────────────────────────────────────────────────────────────

  DON'T double-click index.html to check your site. It half-works, and
  it will make you think the site is broken when it isn't.

  Here's why. Your pages live at addresses like /services/mca-specialist/
  — a folder, not a file. Every real web server (Netlify, cPanel, Vercel,
  Cloudflare) knows that a request for a folder means "serve the
  index.html inside it". That rule is what DirectoryIndex does in the
  .htaccess file included here.

  Opening a file directly uses file:// instead of http://, and file://
  has no such rule. Click a link to /about/ and your browser shows you
  a directory listing — "Index of /about/, index.html, 18.8 kB" — rather
  than the page. Nothing is wrong with the link. There's just no server
  to interpret it.

  SO, TO PREVIEW LOCALLY:

    Windows  ->  double-click  preview-local-WINDOWS.bat
    Mac      ->  double-click  preview-local-MAC.command
                 (first time: right-click -> Open -> confirm)

  A small window opens and your browser goes to http://localhost:8080/.
  Now every link behaves exactly as it will on your live host. Leave
  that window open while you browse; close it when you're finished.

  Both launchers need Python, which Macs already have. On Windows, if it
  tells you Python is missing, the simpler route is just to deploy —
  Netlify's drag-and-drop takes about thirty seconds and gives you a real
  URL to test on.

  These two files do nothing on a live server. Upload them or delete
  them, whichever you prefer. robots.txt already tells crawlers to
  ignore them.

  WHY THE LINKS DON'T END IN index.html
  Because /services/mca-specialist/ is the address that should rank, get
  shared and appear in search results — and it's the one in your sitemap
  and in every canonical tag on the site. If the links pointed at
  /services/mca-specialist/index.html instead, the .htaccess would 301
  every single one of them back to the clean address: slower for
  visitors, and it splits the signals between two addresses for the same
  page. Clean URLs are the correct setup. The local preview is the fix.

───────────────────────────────────────────────────────────────────────────
11. YOUR INTRO VIDEO — AND HOW TO SWAP IT
───────────────────────────────────────────────────────────────────────────

  Your YouTube intro is embedded on the homepage, in its own section just
  under the hero. It uses youtube-nocookie.com, so YouTube sets no
  tracking cookies until a visitor actually presses play, and it is
  lazy-loaded so it costs nothing on page load.

  It also has VideoObject schema attached, which is what makes a video
  eligible to appear with a thumbnail in Google results.

  TO CHANGE THE VIDEO LATER
  Open index.html and find this line (search for "nocookie"):

      src="https://www.youtube-nocookie.com/embed/HJg56OIPxYg?rel=0&modestbranding=1"

  Replace HJg56OIPxYg with the ID of your new video. The ID is the part
  after "youtu.be/" or after "watch?v=" in any YouTube link.

  Then search index.html for HJg56OIPxYg again — it appears three more
  times, in the VideoObject schema (contentUrl, embedUrl, thumbnailUrl).
  Replace all four and you're done. A find-and-replace across index.html
  for HJg56OIPxYg is the quickest way.

  While you're there, update "uploadDate" in the schema to the date the
  new video went live, and the "name" and "description" if the subject
  changed.

  ONE THING WORTH ADDING
  The schema has no "duration" field, because I don't know how long your
  video is. Google prefers it. Find the runtime on YouTube and add it in
  ISO 8601 format next to uploadDate — a 1 minute 12 second video is
  "duration": "PT1M12S". Optional, but it's a thirty-second job.

  IF THE VIDEO SHOWS "ERROR 153" OR "WATCH ON YOUTUBE INSTEAD"

  Error 153 means YouTube refused to play the video inside an embed. It is
  almost always about WHERE the page is being viewed from, not about the
  video itself. Check these in order:

  1. ARE YOU TESTING FROM A FILE, OR FROM localhost?
     This is the most common cause by far. YouTube decides whether an
     embed is allowed by reading the Referer header — the address of the
     page doing the embedding. A page opened as file:/// sends no referrer
     at all, and http://localhost sends one YouTube does not recognise.
     Either way it refuses and you get 153.

     The fix is to test on the real site. Deploy to your host (or a free
     Netlify drag-and-drop) and open https://dippalit.com. The same embed
     that fails locally normally plays fine on a real HTTPS domain.

  2. IS THE VIDEO MARKED "MADE FOR KIDS"?
     YouTube Studio -> Content -> your video -> Audience. If it is set to
     "Yes, it's made for kids", embedding behaviour is restricted and 153
     is a known result. Set it to "No, it's not made for kids".

  3. IS IT PUBLIC OR UNLISTED — NOT PRIVATE?
     Private videos never embed, even for you while signed in. Unlisted
     works fine and keeps it off your channel page.

  4. IS "ALLOW EMBEDDING" ACTUALLY TICKED?
     YouTube Studio -> Content -> video -> Edit -> Show more -> scroll to
     Embedding. You said this is on; worth confirming it saved.

  5. AGE RESTRICTION OR A COPYRIGHT CLAIM ON THE AUDIO
     Either can block embedded playback while the video still plays fine
     on youtube.com. Check the video's Restrictions column in Studio.

  WHAT I CHANGED IN v1.3.1
  Two things that can cause 153 on their own were removed. The embed now
  loads from www.youtube.com rather than youtube-nocookie.com, which is
  stricter about referrers, and the iframe no longer sets a restrictive
  referrerpolicy that could strip the referrer YouTube needs to see.

  There is also now a "Watch on YouTube" button under the player. If the
  embed is ever blocked — by a network, a browser extension, or YouTube
  itself — visitors still have a working route to the video.

  Trade-off worth knowing: youtube-nocookie.com set no tracking cookies
  until someone pressed play. The standard domain does set them. If you
  later add a cookie notice and want the privacy version back, change
  www.youtube.com to www.youtube-nocookie.com in the iframe src — but
  only after confirming playback works on the live domain first.

═══════════════════════════════════════════════════════════════════════════
  Questions, or something needs changing? Come back and tell me what.
═══════════════════════════════════════════════════════════════════════════
