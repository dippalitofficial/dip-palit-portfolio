#!/bin/bash
# ============================================================
#  Local preview for dippalit.com
#
#  Double-clicking index.html does NOT work properly, because
#  a file:// URL cannot serve index.html for a folder — your
#  browser shows a directory listing instead of the page.
#
#  This starts a tiny local web server so the site behaves
#  exactly like it will on your real host.
#
#  Double-click this file, then leave the Terminal window open
#  while you browse. Press Ctrl+C when you're done.
#
#  If macOS refuses to run it: right-click the file, choose
#  Open, then confirm. You only need to do that once.
#
#  This file does nothing on a live server. Upload it or
#  delete it, either is fine.
# ============================================================

cd "$(dirname "$0")" || exit 1

PORT=8080
URL="http://localhost:$PORT/"

echo ""
echo "  Starting local preview of dippalit.com"
echo "  Open this address in your browser:"
echo ""
echo "      $URL"
echo ""
echo "  Leave this window open while browsing."
echo "  Press Ctrl+C to stop."
echo ""

( sleep 1
  if command -v open  >/dev/null 2>&1; then open "$URL"
  elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL"
  fi ) &

if command -v python3 >/dev/null 2>&1; then
  python3 -m http.server "$PORT"
elif command -v python >/dev/null 2>&1; then
  python -m http.server "$PORT"
else
  echo "  Python isn't installed. macOS usually has it already."
  echo "  Otherwise, just upload the site to your host and preview there."
  read -r -p "  Press Enter to close."
fi
