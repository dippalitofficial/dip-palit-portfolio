/* dippalit.com — shared interactions */
(function () {
  'use strict';

  /* Solutions dropdown */
  var dd = document.getElementById('solutions-dropdown');
  if (dd) {
    var tog = dd.querySelector('.nav-dropdown-toggle');
    tog.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      dd.classList.toggle('active');
      tog.setAttribute('aria-expanded', dd.classList.contains('active'));
    });
    document.addEventListener('click', function (e) {
      if (!dd.contains(e.target)) {
        dd.classList.remove('active');
        tog.setAttribute('aria-expanded', 'false');
      }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') dd.classList.remove('active');
    });
  }

  /* Mobile nav — presentation lives in CSS, this only toggles state */
  var mt = document.querySelector('.nav-mobile-toggle');
  var links = document.querySelector('.nav-links');
  if (mt && links) {
    var setNav = function (open) {
      links.classList.toggle('active', open);
      mt.setAttribute('aria-expanded', String(open));
      mt.innerHTML = open
        ? '<i class="fas fa-xmark"></i>'
        : '<i class="fas fa-bars"></i>';
    };

    mt.addEventListener('click', function () {
      setNav(!links.classList.contains('active'));
    });

    /* Close on Escape, on outside click, and after following a link */
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && links.classList.contains('active')) {
        setNav(false);
        mt.focus();
      }
    });
    document.addEventListener('click', function (e) {
      if (
        links.classList.contains('active') &&
        !links.contains(e.target) &&
        !mt.contains(e.target)
      ) {
        setNav(false);
      }
    });
    links.addEventListener('click', function (e) {
      if (e.target.closest('a')) setNav(false);
    });

    /* Reset state if the viewport grows past the mobile breakpoint */
    if (window.matchMedia) {
      var mq = window.matchMedia('(min-width: 961px)');
      var onChange = function (ev) { if (ev.matches) setNav(false); };
      if (mq.addEventListener) mq.addEventListener('change', onChange);
      else if (mq.addListener) mq.addListener(onChange);
    }
  }

  /* FAQ accordions — keyboard accessible */
  document.querySelectorAll('.fc').forEach(function (card) {
    card.setAttribute('tabindex', '0');
    card.setAttribute('role', 'button');
    card.setAttribute('aria-expanded', 'false');
    function toggle() {
      card.classList.toggle('open');
      card.setAttribute('aria-expanded', card.classList.contains('open'));
    }
    card.addEventListener('click', toggle);
    card.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        toggle();
      }
    });
  });

  /* Scroll reveal */
  var faders = document.querySelectorAll('.fade-in');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) {
            en.target.classList.add('visible');
            io.unobserve(en.target);
          }
        });
      },
      { threshold: 0.08, rootMargin: '0px 0px -40px 0px' }
    );
    faders.forEach(function (el) { io.observe(el); });
  } else {
    faders.forEach(function (el) { el.classList.add('visible'); });
  }

  /* Contact form — Formspree AJAX */
  var form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = form.querySelector('button[type="submit"]');
      var ok = document.getElementById('form-msg');
      var bad = document.getElementById('form-err');
      var original = btn.innerHTML;
      bad.style.display = 'none';
      btn.disabled = true;
      btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending…';
      fetch(form.action, {
        method: 'POST',
        body: new FormData(form),
        headers: { Accept: 'application/json' }
      })
        .then(function (res) {
          if (res.ok) {
            ok.style.display = 'block';
            form.reset();
            btn.innerHTML = '<i class="fas fa-check"></i> Message sent';
            setTimeout(function () {
              ok.style.display = 'none';
              btn.disabled = false;
              btn.innerHTML = original;
            }, 6000);
          } else {
            throw new Error('bad response');
          }
        })
        .catch(function () {
          bad.style.display = 'block';
          bad.innerHTML =
            'That didn\'t send. Email <a href="mailto:dippalitofficial@gmail.com" style="color:inherit;text-decoration:underline">dippalitofficial@gmail.com</a> or message me on WhatsApp.';
          btn.disabled = false;
          btn.innerHTML = original;
        });
    });
  }

  /* Current year in footer */
  document.querySelectorAll('[data-year]').forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });
})();
